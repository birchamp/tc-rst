# Haggai

## Definition:

Haggai was a prophet of Judah after the Jews returned home from being captives in Babylon.

* During the period when Haggai was prophesying, King Uzziah was reigning over Judah.
* The prophet Zechariah was also prophesying during this period.
* Haggai and Zechariah exhorted the Jews to rebuild the temple, which had been destroyed by the Babylonians under King Nebuchadnezzar.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Babylon](../names/babylon.md), [Judah](../names/kingdomofjudah.md), [Nebuchadnezzar](../names/nebuchadnezzar.md), [Uzziah](../names/uzziah.md), [Zechariah (OT)](../names/zechariahot.md))

## Bible References:

* [Ezra 5:1-2](rc://en/tn/help/ezr/05/01)
* [Ezra 6:13-15](rc://en/tn/help/ezr/06/13)

## Word Data:

* Strong’s: H2292
