Connect — Hypothetical Conditions
