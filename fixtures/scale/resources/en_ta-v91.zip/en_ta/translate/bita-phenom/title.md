Biblical Imagery — Natural Phenomena
