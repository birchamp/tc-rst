Biblical Imagery — Common Metonymies
