Imperatives — Other Uses
