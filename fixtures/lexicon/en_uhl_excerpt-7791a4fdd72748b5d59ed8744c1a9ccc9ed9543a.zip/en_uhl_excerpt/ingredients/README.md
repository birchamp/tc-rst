# unfoldingWord Hebrew Lexicon

